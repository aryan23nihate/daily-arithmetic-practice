# Daily Arithmetic Practice — publish and sync setup

This is a static, mobile-friendly practice website. It works locally without a database. To sync scores between mobile and computer, publish it online and connect a Supabase project.

## 1. Create the online database
1. Create a free project at https://supabase.com/.
2. In the project dashboard, open **SQL Editor** and run the contents of `supabase_setup.sql`.
3. Open **Project Settings → API** (or **Connect**) and copy the Project URL and the publishable/anon public key. Do **not** use a `service_role` or secret key in the website.
4. Under **Authentication → Providers / Sign In**, enable Email/password sign-in. To avoid verification emails, disable email confirmation in the Auth settings if that option is available on your plan. This app does not send practice questions by email.

## 2. Publish the webpage free with GitHub Pages
1. Sign in to https://github.com/ and create a new public repository, for example `daily-arithmetic-practice`.
2. Upload `index.html` from this folder to the repository's root. (The SQL and README can also be uploaded for your reference.)
3. In the repository, open **Settings → Pages**. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
4. Wait for GitHub Pages to publish. It will show your public website URL on that same Pages settings screen. Open that URL on your phone and computer.

## 3. Connect the webpage to Supabase
1. Open your published website.
2. Expand **Mobile + computer sync → Set up online sync**.
3. Enter the Supabase Project URL and the publishable/anon public key, then tap **Save database settings**.
4. Enter an email address and password, then tap **Create sync account**. You can use the same account on both devices. If email confirmation is enabled, complete it before logging in.
5. On the second device, open the same website, enter the same Supabase settings and account, then tap **Log in & sync**.
6. Tap **Sync now** after completing practice. Results are stored under your account and can be accessed on both devices.

## Notes
- No practice sets are emailed to you. The email field is only for the optional Supabase account login.
- Local scores stay in that browser too. Use **Sync now** to upload/download history.
- Do not put a Supabase service-role key in the page. Only use the publishable/anon key with Row Level Security enabled.
- A live public URL cannot be created by this package alone; you must complete the hosting steps in your own GitHub account.
